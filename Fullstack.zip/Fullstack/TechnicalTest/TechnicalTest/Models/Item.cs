﻿namespace TechnicalTest.Models
{
    public class Item
    {
     
        public int Id { get; set; }
        public string Nama { get; set; }
        public int Harga { get; set; }
        public int Stok { get; set; }
        public string Kategori { get; set; }
        public string UrlGambar { get; set; }
    }
}
