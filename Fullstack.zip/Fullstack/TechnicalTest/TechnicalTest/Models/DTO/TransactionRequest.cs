﻿namespace TechnicalTest.Models.DTO
{
    public class TransactionRequest
    {
        public int ItemId { get; set; } // ID item yang dijual
        public int Quantity { get; set; } // Jumlah item yang dijual
    }
}
