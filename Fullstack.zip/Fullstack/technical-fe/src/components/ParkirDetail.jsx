/* eslint-disable no-undef */
/* eslint-disable react/prop-types */
const TransactionDetail = ({ detail }) => {
  if (!detail) return null;

  return (
    <div className="mt-6 bg-white p-6 rounded-lg shadow-lg">
      <h2 className="text-xl font-bold mb-4">Detail Transaksi</h2>
      <p>ID Transaksi: {detail.Id}</p>
      <p>Type Item: {detail.Nama}</p>
      <p>Quantity: {detail.Quantity}</p>
      <p>Harga: {detail.Harga}</p>
      <p>Total Harga: {detail.TotalHarga}</p>
      <p>Kategory: {detail.Kategori}</p>
      <p>Tanggal Transaksi: {new Date(detail.TanggalTransaksi).toLocaleString()}</p>
      <button onClick={() => handleDetail(detail.Id, 'sudah bayar')} className="mt-4 px-4 py-2 bg-blue-500 text-white rounded-lg shadow hover:bg-blue-600 transition duration-300">Sudah Bayar</button>

    </div>
  );
};

export default TransactionDetail;
