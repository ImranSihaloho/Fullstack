import { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import ParkirForm from '../components/ParkirForm';
import ParkirDetail from '../components/ParkirDetail';
import ParkirList from '../components/ParkirList';
import { Link } from 'react-router-dom';
import { LogOut } from 'lucide-react';
import { Clapperboard} from 'lucide-react';
import { Bike} from 'lucide-react';



const Parkir = () => {
  const [item, setItem] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [id, setId] = useState(null);
  const [itemId, setItemId] = useState(0);
  const [quantity, setQuantity] = useState('');
  const [detail, setDetail] = useState(null);
  const navigate = useNavigate();

  // Cek apakah pengguna sudah login
  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      navigate('/'); // Arahkan ke halaman login jika belum login
    } else {
      loadItems(token);
      loadTransaction(token);
    }
  }, [navigate]);

  const loadItems = async (token) => {
    try {
      const response = await axios.get('http://localhost:5149/api/Items', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setItem(response.data);
    } catch (err) {
      console.error('Gagal mengambil data TypeTransportasi:', err);
    }
  };

  const loadTransaction = async (token) => {
    try {
      const response = await axios.get("http://localhost:5149/api/Transaction/transactions", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setTransactions(response.data);
    } catch (err) {
      console.error('Gagal mengambil data Transaksi:', err);
    }
  };

  const handleSave = async (event) => {
    event.preventDefault();
    const token = localStorage.getItem('token');
    try {
      const txid = parseInt(itemId);
      const data = {
        itemId: txid,
        quantity,
      };

      if (id === null) {
        await axios.post('http://localhost:5149/api/Transaction/transactions', data, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
      } else {
        await axios.put(`https://localhost:7122/api/Parkir/${id}`, data, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
      }
      resetForm();
      loadTransaction(token);
      alert('Data parkir berhasil disimpan');
    } catch (err) {
      console.error(err);
      alert('Terjadi kesalahan saat menyimpan data');
    }
  };

  const resetForm = () => {
    setId(null);
    setItemId('');
    setQuantity('');
    setDetail(null);
  };

  const handleEdit = (transaksi) => {
    setId(transaksi.id);
    setItemId(transaksi.itemId);
    setQuantity(transaksi.quantity);
    // setWaktuMasuk(new Date(parkir.waktuMasuk).toISOString().substring(0, 16));
  };

  const handleDelete = async (id) => {
    const token = localStorage.getItem('token');
    if (window.confirm('Apakah Anda yakin ingin menghapus data ini?')) {
      await axios.delete(`https://localhost:7122/api/Parkir/${id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      resetForm();
      loadTransaction(token);
    }
  };

  const handleDetail = async (id, status) => {
    const token = localStorage.getItem('token');
    try {
      const response = await axios.get(`http://localhost:5149/api/Transaction/transactions`, {
        params: { status },
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setDetail(response.data);
    } catch (err) {
      console.error(err);
      alert('Gagal mengambil detail parkir');
    }
  };

  return (
    <div>
    <header className="bg-green-600 text-white py-4">
    <nav className="container mx-auto">
      <ul className=" flex bg-origin-padding gap-10">
        <li><Link to="/parkir" className="hover:underline"><Clapperboard size={44} strokeWidth={2.75} /></Link></li>
        <li><Link to="/typeTransportasiCrud" className="hover:underline"><Bike  size={44} strokeWidth={2.75} /></Link></li>
        <li><Link to="/" className="hover:underline"><LogOut  size={44} strokeWidth={2.75} /></Link></li>
      </ul>
    </nav>
  </header>
    <div className="container mx-auto p-4">
      <ParkirForm
        item={item}
        itemId={itemId}
        setItemId={setItemId}
        quantity={quantity}
        setQuantity={setQuantity}
        handleSave={handleSave}
        resetForm={resetForm}
      />
      <ParkirList
        transactions={transactions}
        handleEdit={handleEdit}
        handleDelete={handleDelete}
        handleDetail={handleDetail}
      />
      <ParkirDetail detail={detail} />
    </div>
    </div>
  );
};

export default Parkir;
